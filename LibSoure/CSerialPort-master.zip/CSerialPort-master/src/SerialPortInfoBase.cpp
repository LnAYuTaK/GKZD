﻿#include "CSerialPort/SerialPortInfoBase.h"

CSerialPortInfoBase::CSerialPortInfoBase() {}

CSerialPortInfoBase::~CSerialPortInfoBase() {}
