var searchData=
[
  ['subscription_20example_703',['Subscription example',['../subscribe.html',1,'']]],
  ['subscription_20wildcards_704',['Subscription wildcards',['../wildcard.html',1,'']]]
];
